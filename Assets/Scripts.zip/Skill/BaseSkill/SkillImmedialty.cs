namespace Skill.BaseSkill
{
    public abstract class SkillImmedialty : BaseSkill
    {

    }
}
namespace GameManagers
{
    public interface IManagerIResettable
    {
        public void Clear();
    }
}
namespace GameManagers.Interface.DataManager
{
    public interface ILoginDataSpreadSheet
    {
        public string LoginDataSpreadsheetID { get; }

        public string UserAuthenticateDatasheetName { get; }

    }
}

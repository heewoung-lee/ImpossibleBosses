using UnityEngine;

namespace GameManagers.Interface.DataManager
{
    public interface IGameDataSpreadSheet
    {
        public string GameDataSpreadsheetID { get; }
        
    }
}

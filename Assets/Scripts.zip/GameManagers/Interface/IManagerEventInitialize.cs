namespace GameManagers
{
    public interface IManagerEventInitialize
    {
        public void InitializeVivoxEvent();
    }
}
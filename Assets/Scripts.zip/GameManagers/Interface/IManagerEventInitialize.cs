namespace GameManagers.Interface
{
    public interface IManagerEventInitialize
    {
        public void InitializeVivoxEvent();
    }
}
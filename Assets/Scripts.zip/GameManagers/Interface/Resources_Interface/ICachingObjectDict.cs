using System.Collections.Generic;
using UnityEngine;

public interface ICachingObjectDict
{
    public Dictionary<string, GameObject> CachingObjectDict{get;}
}

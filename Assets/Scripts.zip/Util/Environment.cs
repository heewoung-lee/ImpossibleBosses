using UnityEngine;

namespace Util
{
    public class Environment : MonoBehaviour
    {
    }
}
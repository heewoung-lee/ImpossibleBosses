using System.Collections.Generic;
using UnityEngine;

namespace Util
{
    public interface IPopulatingDefaultValue
    {
        public void PopulatingDefaultValue(List<Object> searchedObject);
    }
}

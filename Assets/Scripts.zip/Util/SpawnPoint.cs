using UnityEngine;

namespace Util
{
    public class SpawnPoint : MonoBehaviour
    {
        Transform _spawnTr;
        Transform SpawnTr { get => _spawnTr; }

    }
}

using NetWork.BaseNGO;

namespace NetWork.NGO.InitializeNGO.EffectVFX
{
    public class NgoDustInitalize : NgoPoolingInitalizeBase
    {
        public override string PoolingNgoPath => "Prefabs/Paticle/AttackEffect/Dust_Paticle";

        public override int PoolingCapacity => 100;

    }
}

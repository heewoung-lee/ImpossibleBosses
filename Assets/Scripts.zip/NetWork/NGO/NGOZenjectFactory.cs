using BehaviorDesigner.Runtime.Tasks.Unity.UnityGameObject;
using Unity.Netcode;
using UnityEngine;
using Zenject;

namespace NetWork.NGO
{
    public abstract class NgoZenjectFactory<T> : IFactory<T> where T : NetworkBehaviour
    {
        protected DiContainer _container;
        protected GameObject _ngo;
        private bool _isregistedHandler = false;
        public T Create()
        {
            if (_isregistedHandler == false && NetworkManager.Singleton != null)
            {
                NgoZenjectHandler handler = new NgoZenjectHandler(_container,_ngo);
                NetworkManager.Singleton.PrefabHandler.AddHandler(_ngo, handler);
                _isregistedHandler = true; // 등록 완료 플래그 설정
            }
            
            
            GameObject createdNgo = UnityEngine.Object.Instantiate(_ngo);
            _container.InjectGameObject(createdNgo);
            
            return createdNgo.GetComponent<T>();
        }
    }
}

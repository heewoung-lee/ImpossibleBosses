using NetWork.NGO;
using UnityEngine;
using Zenject;

namespace ProjectContextInstaller
{
    public class RpcCallerInstaller : MonoInstaller
    {
        public override void InstallBindings()
        {
            GameObject ngo = Resources.Load<GameObject>("Prefabs/NGO/NgoRPCCaller");
            Container.Bind<IFactory<NgoRPCCaller>>().To<NgoRPCCaller.NgoRPCCallerFactory>().AsSingle().WithArguments(ngo);
        }
    }
}

namespace Scene
{
    public interface ISkillInit
    {
   
    }
}

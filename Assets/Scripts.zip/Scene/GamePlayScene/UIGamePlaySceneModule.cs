using Module.UI_Module;

namespace Scene.GamePlayScene
{
    public class UIGamePlaySceneModule : InGameUIModule
    {
    
    }
}

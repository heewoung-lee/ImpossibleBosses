using GameManagers.Interface.Resources_Interface;
using NetWork.NGO;
using NetWork.NGO.UI;
using Scene.CommonInstaller;
using Unity.Netcode;
using Unity.VisualScripting;
using UnityEngine;
using Zenject;
using ZenjectTool;

namespace Scene.RoomScene.Installer
{
    public class RoomSceneGameObjectInstaller : MonoInstaller
    {
        public override void InstallBindings()
        {
            GameObject characterSelectRect = Resources.Load<GameObject>("Prefabs/NGO/NGOUICharacterSelectRect");
            Container.Bind<IFactory<CharacterSelectorNgo>>().To<CharacterSelectorNgo.CharacterSelectorNgoFactory>()
                .AsSingle().WithArguments(characterSelectRect);


            GameObject ngoUIRootCharacterSelect = Resources.Load<GameObject>("Prefabs/NGO/NGOUIRootChracterSelect");
            Container.Bind<IFactory<NgoUIRootCharacterSelect>>()
                .To<NgoUIRootCharacterSelect.NgoUIRootCharacterSelectFactory>().AsSingle()
                .WithArguments(ngoUIRootCharacterSelect);
        }
    }
    
    
}

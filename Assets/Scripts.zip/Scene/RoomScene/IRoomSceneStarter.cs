namespace Scene.RoomScene
{
    public interface IRoomSceneStarter
    {
        public void RoomSceneStart();
    }
}

namespace Scene
{
    public interface ISceneMover
    {
        public void MoveScene();
    }
}

namespace Scene
{
    public interface IPlayerPositionController
    {
        public void SetPlayerPosition();
    }
}

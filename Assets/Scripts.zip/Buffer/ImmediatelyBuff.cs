namespace Buffer
{
    public abstract class ImmediatelyBuff : BuffModifier
    {

    }
}
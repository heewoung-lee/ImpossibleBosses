public interface ISceneController
{
    public MoveSceneController SceneMoverController { get; }
}
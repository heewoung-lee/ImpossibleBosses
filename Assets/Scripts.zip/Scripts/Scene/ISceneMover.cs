using UnityEngine;

public interface ISceneMover
{
    public void MoveScene();
}

using UnityEngine;

public interface ISkillInit
{
   
}

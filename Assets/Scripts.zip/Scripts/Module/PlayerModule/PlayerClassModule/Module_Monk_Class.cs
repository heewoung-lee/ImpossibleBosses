using UnityEngine;

public class Module_Monk_Class : Module_Player_Class
{
    public override Define.PlayerClass PlayerClass => Define.PlayerClass.Monk;
}

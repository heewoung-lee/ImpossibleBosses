using UnityEngine;

public class Module_Acher_Class : Module_Player_Class
{
    public override Define.PlayerClass PlayerClass => Define.PlayerClass.Archer;
}

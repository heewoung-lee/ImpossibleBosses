using UnityEngine;

public class Module_Mage_Class : Module_Player_Class
{
    public override Define.PlayerClass PlayerClass => Define.PlayerClass.Mage;
}

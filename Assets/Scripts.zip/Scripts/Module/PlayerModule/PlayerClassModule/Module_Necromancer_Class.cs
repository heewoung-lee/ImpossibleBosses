using UnityEngine;

public class Module_Necromancer_Class : Module_Player_Class
{
    public override Define.PlayerClass PlayerClass => Define.PlayerClass.Necromancer;
}

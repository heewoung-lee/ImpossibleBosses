public interface IAttackInfo
{
    public float AttackPreTime { get; }
    public string AttackName { get; }
}
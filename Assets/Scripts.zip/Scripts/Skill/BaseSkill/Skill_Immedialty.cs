using UnityEngine;

public abstract class Skill_Immedialty : BaseSkill
{

}
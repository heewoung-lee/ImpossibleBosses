
public interface INetWorkPoolableSkill
{
    public void RegisterPoolDictToskill(string path);
}
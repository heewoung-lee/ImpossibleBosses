public abstract class Immediately_Buff : Buff_Modifier
{

}
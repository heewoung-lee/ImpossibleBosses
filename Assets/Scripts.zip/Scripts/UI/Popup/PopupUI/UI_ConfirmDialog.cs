public class UI_ConfirmDialog : UI_AlertPopupBase
{
    protected override void StartInit()
    {
    
    }
}
using System;
using UnityEngine;

public class UI_AlertDialog : UI_AlertPopupBase
{
    protected override void StartInit()
    {
        
    }
}

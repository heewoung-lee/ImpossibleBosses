using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting.Antlr3.Runtime.Misc;
using UnityEngine;
using UnityEngine.UI;
public class UI_HPBar : UI_Base
{
    private readonly Vector3 OFFSET_HPBAR = new Vector3(0, 1.5f,0);
    BaseStats _stats;
    Slider _hpSlider;
    CanvasGroup _canvasGroup;
    bool _isDamaged = false;
    enum HPBarSlider
    {
        HPBar
    }

    protected override void AwakeInit()
    {
        Bind<Slider>(typeof(HPBarSlider));
        _hpSlider = Get<Slider>((int)HPBarSlider.HPBar);
        _canvasGroup = GetComponent<CanvasGroup>();
        _canvasGroup.alpha = 0;//ó������ HP�� �Ⱥ��̰� ���� �¾����� ���̰Բ� ����
    }

    protected override void StartInit()
    {
        _stats = GetComponentInParent<BaseStats>();
        transform.position = _stats.transform.position+ OFFSET_HPBAR * (_stats.GetComponent<Collider>().bounds.size.y);
        _stats.Event_Attacked += SetHpUI;
    }

    void LateUpdate()
    {
        if(_isDamaged)
        transform.rotation = Camera.main.transform.rotation;
    }
    public void SetHpUI(int damage, int currentHp)
    {
        _isDamaged = true;
        _hpSlider.value = (float)currentHp / (float)_stats.MaxHp;
        _canvasGroup.alpha = 1f;
        StopCoroutine(Hpbar_fadeaway());
        StartCoroutine(Hpbar_fadeaway());

    }

    IEnumerator Hpbar_fadeaway()
    {
        while (true)
        {
            _canvasGroup.alpha -= 0.3f * Time.deltaTime;

            if(_canvasGroup.alpha <= 0f)
            {
                _isDamaged = false;
                yield break;
            }
            yield return null;
        }
    }
}

public interface IManagerInitializable
{
    public void Init();
}
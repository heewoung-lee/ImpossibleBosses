using System;
using UnityEngine;

public interface IPoolSpawnBehavior
{
    void RegisterSpawnCallback(Action callback);
}
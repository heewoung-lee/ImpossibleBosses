public interface IManagerIResettable
{
    public void Clear();
}
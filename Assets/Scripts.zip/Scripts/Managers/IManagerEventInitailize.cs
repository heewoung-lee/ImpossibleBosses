public interface IManagerEventInitailize
{
    public void InitalizeVivoxEvent();
}
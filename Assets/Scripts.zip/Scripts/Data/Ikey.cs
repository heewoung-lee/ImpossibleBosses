public interface Ikey<T>
{
    T Key { get; }
}
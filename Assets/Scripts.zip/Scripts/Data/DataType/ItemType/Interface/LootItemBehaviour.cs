using UnityEngine;

public interface LootItemBehaviour
{
    public void SpawnBahaviour(Rigidbody rigid);
}
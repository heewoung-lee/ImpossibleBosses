public interface IItemDescriptionForm
{
    public string GetItemEffectText();
}
namespace UI.Scene.Interface
{
    public interface ISceneChangeBehaviour
    {
        public void OnBeforeSceneUnload();
    }
}
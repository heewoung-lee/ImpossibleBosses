namespace UI.Popup.PopupUI
{
    public class UIAlertDialog : UIAlertPopupBase
    {
        protected override void StartInit()
        {
        
        }
    }
}

namespace UI.Popup.PopupUI
{
    public class UIConfirmDialog : UIAlertPopupBase
    {
        protected override void StartInit()
        {
    
        }
    }
}
using UnityEngine;

namespace UI
{
    public class UIBaseItem : UIBase
    {
        protected override void StartInit()
        {
        }

        protected override void AwakeInit()
        {
        }
    }
}

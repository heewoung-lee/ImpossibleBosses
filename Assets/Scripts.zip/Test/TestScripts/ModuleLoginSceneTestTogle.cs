using GameManagers;
using GameManagers.Interface;
using GameManagers.Interface.UI_Interface;
using Test.TestUI;
using UnityEngine;
using Zenject;

namespace Test.TestScripts
{
    public class ModuleLoginSceneTestTogle : MonoBehaviour
    {
        [Inject] private IUISceneManager _sceneUIManager;

        void Awake()
        {
            LogInTestToggle testTogle = _sceneUIManager.GetSceneUIFromResource<LogInTestToggle>(path: "Prefabs/UI/TestUI/LogInTestToggle");
        }
    }
}

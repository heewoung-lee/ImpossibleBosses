using UnityEngine;

public class ParticleLifetimeSync : MonoBehaviour
{
    //이 클래스는 파티클중 Duration과 StartLifeTime을 맞추기 위한 클래스
}

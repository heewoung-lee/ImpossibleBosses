using UnityEngine;

public class LoopingParticle : MonoBehaviour
{
    //루핑 파티클을 지정
}

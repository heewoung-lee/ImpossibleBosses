using UnityEngine;

namespace Data.Item
{
    public class ItemShopContentCoordinate : MonoBehaviour
    {

    }
}

using UnityEngine;

namespace Data.Item
{
    public class InventoryContentCoordinate : MonoBehaviour
    {
        //이 스크립트는 ItemInventory의 Content위치를 알기위한 클래스
    }
}

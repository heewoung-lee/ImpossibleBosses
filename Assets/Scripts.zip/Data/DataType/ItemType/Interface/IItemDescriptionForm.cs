
    namespace Data.DataType.ItemType.Interface
    {
        public interface IItemDescriptionForm
        {
            public string GetItemEffectText();
        }
    }

using UnityEngine;

namespace Data.DataType.ItemType.Interface
{
    public interface ILootItemBehaviour
    {
        public void SpawnBahaviour(Rigidbody rigid);
    }
}
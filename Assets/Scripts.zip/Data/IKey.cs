
namespace Data
{
    public interface IKey<T>
    {
        T Key { get; }
    }
}
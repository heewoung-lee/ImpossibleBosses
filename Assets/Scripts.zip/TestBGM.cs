using System.Collections;
using System.Collections.Generic;
using GameManagers;
using UnityEngine;
using Util;

public class TestBGM : MonoBehaviour
{

    void Start()
    {
        //Managers.SoundManager.Play("Sounds/001.BGM", Define.Sound.BGM);
    }


}

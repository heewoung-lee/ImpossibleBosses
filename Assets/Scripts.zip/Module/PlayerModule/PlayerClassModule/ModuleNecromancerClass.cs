using Util;

namespace Module.PlayerModule.PlayerClassModule
{
    public class ModuleNecromancerClass : ModulePlayerClass
    {
        public override Define.PlayerClass PlayerClass => Define.PlayerClass.Necromancer;
    }
}

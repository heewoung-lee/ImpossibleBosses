using Util;

namespace Module.PlayerModule.PlayerClassModule
{
    public class ModuleAcherClass : ModulePlayerClass
    {
        public override Define.PlayerClass PlayerClass => Define.PlayerClass.Archer;
    }
}

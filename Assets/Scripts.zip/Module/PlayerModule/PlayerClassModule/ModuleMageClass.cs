using Util;

namespace Module.PlayerModule.PlayerClassModule
{
    public class ModuleMageClass : ModulePlayerClass
    {
        public override Define.PlayerClass PlayerClass => Define.PlayerClass.Mage;
    }
}

using System.Collections.Generic;
using System.Linq;
using GameManagers;
using GameManagers.Interface.Resources_Interface;
using Scene;
using Skill;
using Skill.BaseSkill;
using Unity.Netcode;
using UnityEngine;
using UnityEngine.SceneManagement;
using Util;
using Zenject;

namespace Module.PlayerModule.PlayerClassModule
{
    public abstract class ModulePlayerClass : MonoBehaviour
    {
        public abstract Define.PlayerClass PlayerClass { get; }


        private Dictionary<string, BaseSkill> _playerSkill;
        
        [Inject] IInstantiate _instantiate;
        [Inject]SkillManager _skillManager; 
        public virtual void InitializeOnAwake()
        {
        
        }
        public void OnEnable()
        {
            Managers.RelayManager.NetworkManagerEx.SceneManager.OnLoadEventCompleted += ChangeLoadScene;
        }
        public void OnDisable()
        {
            Managers.RelayManager.NetworkManagerEx.SceneManager.OnLoadEventCompleted -= ChangeLoadScene;
        }
        public virtual void InitializeOnStart()
        {
        }
  
        private void ChangeLoadScene(string sceneName, LoadSceneMode loadSceneMode, List<ulong> clientsCompleted, List<ulong> clientsTimedOut)
        {

            if (Managers.SceneManagerEx.GetCurrentScene is not ISkillInit)
                return;

            if (clientsCompleted.Contains(Managers.RelayManager.NetworkManagerEx.LocalClientId) is false)
                return;

            InitializeSkillsFromManager();
        }

        private void InitializeSkillsFromManager()
        {
            if (GetComponent<NetworkObject>().IsOwner == false)
                return;

            _playerSkill = _skillManager.AllSKillDict
                .Where(skill => skill.Value.PlayerClass == PlayerClass)
                .ToDictionary(skill => skill.Key, skill => skill.Value);//각 클래스에 맞는 스킬들을 추린다

            if (_skillManager.UISkillBar == null)
            {
                _skillManager.DoneUISkilBarInitEvent += AssignSkillsToUISlots;
            }
            else
            {
                AssignSkillsToUISlots();
            }
        }


        public void AssignSkillsToUISlots()
        {
            foreach (BaseSkill skill in _playerSkill.Values)
            {
                GameObject skillPrefab = _instantiate.Instantiate("Prefabs/UI/Skill/UI_SkillComponent");
                SkillComponent skillcomponent = skillPrefab.GetOrAddComponent<SkillComponent>();
                skillcomponent.SetSkillComponent(skill);
                Transform skillLocation = _skillManager.UISkillBar.SetLocationSkillSlot(skillcomponent);
                skillcomponent.AttachItemToSlot(skillcomponent.gameObject, skillLocation);
            }
        }
        private void Awake()
        {
            _playerSkill = new Dictionary<string, BaseSkill>();
            InitializeOnAwake();
        }

        private void Start()
        {
            InitializeOnStart();
        }
    }
}

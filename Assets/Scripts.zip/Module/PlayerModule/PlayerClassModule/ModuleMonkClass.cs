using Util;

namespace Module.PlayerModule.PlayerClassModule
{
    public class ModuleMonkClass : ModulePlayerClass
    {
        public override Define.PlayerClass PlayerClass => Define.PlayerClass.Monk;
    }
}

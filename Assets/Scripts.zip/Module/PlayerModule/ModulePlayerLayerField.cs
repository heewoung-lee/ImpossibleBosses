using UnityEngine;

namespace Module.PlayerModule
{
    public class ModulePlayerLayerField : MonoBehaviour
    {
    }
}
